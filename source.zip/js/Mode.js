var Mode = function() {
    var e = false
};
mindmaps.mode = new Mode