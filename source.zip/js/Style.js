mindmaps.plugins["style"] = {
    startOrder: 100,
    onUIInit: function(e, t) {},
    onCreateNode: function(e) {},
    onNodeUpdate: function(e, t) {}
}